SAHAER KHAN — REAL WEBSITE VERSION

এই version-এ আপনার দেওয়া ১০টি বাস্তব কাজের ছবি যুক্ত করা হয়েছে।

লোকালভাবে দেখার নিয়ম:
1. ZIP extract করুন।
2. index.html Chrome-এ খুলুন।
3. বাংলা / English / العربية পরিবর্তন করে দেখুন।
4. Projects অংশে ছবিতে চাপ দিলে বড় ছবি দেখা যাবে।

Production launch-এর আগে:
- আপনার Instagram/Facebook link বসাতে হবে
- Service areas (Kuwait-এর কোন কোন এলাকা) নিশ্চিত করতে হবে
- চাইলে logo আলাদা করে বসাতে হবে
- Domain + hosting সংযুক্ত করতে হবে
- আপনার কাজের ভিডিওগুলো যুক্ত করতে হবে
- চাইলে Google Maps/Google Business Profile link যোগ করা যাবে

বর্তমান WhatsApp/Phone: +965 66884145
